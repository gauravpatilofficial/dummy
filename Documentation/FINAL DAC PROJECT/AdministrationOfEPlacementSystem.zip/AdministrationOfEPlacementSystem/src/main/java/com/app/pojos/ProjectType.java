package com.app.pojos;

public enum ProjectType {
MINOR,MAJOR,minor,major;
}
