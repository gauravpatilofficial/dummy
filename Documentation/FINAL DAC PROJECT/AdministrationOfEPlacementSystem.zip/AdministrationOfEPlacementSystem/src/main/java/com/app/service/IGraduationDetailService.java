package com.app.service;

import com.app.pojos.GraduationDetail;

public interface IGraduationDetailService {
	
	GraduationDetail addGraduationDetail(GraduationDetail d);

}
