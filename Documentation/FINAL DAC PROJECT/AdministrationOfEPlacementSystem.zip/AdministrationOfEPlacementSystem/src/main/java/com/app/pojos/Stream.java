package com.app.pojos;

public enum Stream {
MECHANICAL,COMPUTER,ELECTRICAL,IT;
}
