package com.app.service;

import com.app.pojos.SchoolDetail;

public interface ISchoolDetailService {
	
	SchoolDetail addSchoolDetail(SchoolDetail s);

}
