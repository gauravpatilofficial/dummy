package com.app.pojos;

public enum Degree {
	BE,BTECH,MTECH,ME;
}
