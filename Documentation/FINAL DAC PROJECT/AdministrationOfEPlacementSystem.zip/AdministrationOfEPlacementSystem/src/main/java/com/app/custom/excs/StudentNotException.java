package com.app.custom.excs;

public class StudentNotException extends RuntimeException {
 public StudentNotException(String msg) {
	 super(msg);
 }
}
